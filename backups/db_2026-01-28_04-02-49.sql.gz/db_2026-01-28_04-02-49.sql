pg_dump: error: aborting because of server version mismatch
pg_dump: detail: server version: 17.7 (Debian 17.7-3.pgdg13+1); pg_dump version: 16.11 (Ubuntu 16.11-1.pgdg24.04+1)
